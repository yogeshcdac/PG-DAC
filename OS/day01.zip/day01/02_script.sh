#!/bin/bash

# Single Line Comment

<<Multi_line
hello
dac student
Multi_line

<<Commentmaker
line1...
line2...
Commentmaker
