#!/bin/bash

a=3
name=Max

echo "$a"
echo "$name"

echo "Enter your name"
read nom
echo "$nom"

echo "Enter your ID"
read id
echo "$id"
