#!/bin/bash

echo Enter Your First Name
read fname

echo Enter Your Middle Name
read mname

echo Enter Your Last Name
read lname

echo "Welcome $fname $mname $lname"
