#ifndef UTILS_H
#define UTILS_H
#include"employeeHeader.h"
void sortBySalary(Employee [], int);
#endif
