class Student
{

  private:
	  int rno;
	  char name[50];
  public:
	void Accept();
	void Display();




};



