#include<iostream>
using namespace std()
class Employee
{
	private:
	int empNo;
	int salary;
	string name;
	
	public:
	Employee()
	{
		empNo=0;
		salary=1;
		name="NULL";
	}

	int getSalary()
	{
		return salary;
	}
	
	void setDetails(int e,int s, string nom)
	{
		empNo=a;
		salary=s;
		nom=name;
	}
}


int main()
{
	int n;
	Employee[50];
	cout<<"Enter number of Employees";
	cin>>n;
	for(i=0;i<n;i++)
	{
		setDetails;
	}
	return 0;
}
void SortOfStudents()
{

}
