#include<iostream>
int main()
{
int a,b;
}
void studentSorter()
